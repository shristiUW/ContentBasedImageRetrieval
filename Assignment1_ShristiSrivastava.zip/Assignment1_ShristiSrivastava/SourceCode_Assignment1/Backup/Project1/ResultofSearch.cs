﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;



namespace Project1
{
    public partial class ResultofSearch : Form
    {
        //set up global varabiles for class
        static public bool useMethod1 = true;
        ArrayList list;
        ArrayList currentPicturesList = new ArrayList(20);
        Form1 originalForm;
        ArrayList QueryPictureIntensity;
        ArrayList QueryPictureColor;
        int page;
        int totalPages;
        string imageFoldPath;
        DisplayPicture displayForm;


        public ResultofSearch(Form1 form)
        {
            //initialize information when form is created
            originalForm = form;
            InitializeComponent();
            list = new ArrayList();
            //set up list to hold 20 pictures
            for (int i = 0; i < 20; i++)
            {
                currentPicturesList.Add(0);
            }

        }
        //function to search through database based on the Query Picture sent in
        public void doSearch(string QueryPicture, string folderPath, bool method1)
        {
            ////////////////////
            ///add your code///
            ////////////////////
            
            //calculate the number of pages needed if we want 20 pictures per page
            double numberPerPage = (list.Count / 20.0);
            totalPages = (int)Math.Ceiling(numberPerPage);
            pageLabel.Text = "Page 1 /Out of " + totalPages;
            page = 0;
            //resize the picture box for the query image
            Size newS = new Size(qWidth, qHeight);
            queryPicture.Size = newS;
            queryPicture.Image = imageQ;
            //set up the check next to the right check box
            if (useMethod1)
            {
                checkBox1.Checked = true;
                checkBox2.Checked = false;
            }
            else
            {
                checkBox2.Checked = true;
                checkBox1.Checked = false;
            }
            //display picture to screen
            displayResults();
            
            
        }
       
        //function to read a file in from memoru and save each line as a string in the array list
        public void readFile(ArrayList fileList, string file)
        {
            StreamReader tr = new StreamReader(file);
            string line;
            while ((line = tr.ReadLine()) != null)
            {
                fileList.Add(line);
            }
            tr.Close();
        }
        //write a new line to the file
        public void addToFile(string line, string file)
        {
            FileStream fileWriter = new FileStream(file, FileMode.Append);
            StreamWriter tw = new StreamWriter(fileWriter);
            tw.WriteLine(line);
            tw.Close();
            fileWriter.Close();

        }
        
	   
	   ///////////////////////////////////////////////
	   //your code //
       ///////////////////////////////////////////////
       
 
					   
		//this function is used to display the results of the search to the screen
        public void displayResults()
        {
            //offset used to scan through the list and get the right pictures based on the current page we are on 
            int offSet = page * 20;
            //each block does same thing will only comment one of them!!!!!!!!!!!!!!!!!!!!
            //check to make sure we are still with in the array and picture still exists
            if ((0 + offSet) < list.Count && File.Exists(((PictureClass)list[0 + offSet]).getPath()))
            {
                //add the path to the current page listing
                currentPicturesList[0] = ((PictureClass)list[0 + offSet]).getPath();
                //get the image from the memory and create thumbnail of it
                Bitmap image1 = (Bitmap)Bitmap.FromFile(((PictureClass)list[0 + offSet]).getPath());
                Image newImag1 = image1.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                //set thumbnail as the image of the picturebox starting from one and moving across then down
                pictureBox1.Image = newImag1;
            }
            else
            {
                //if we are past the array or image does not exist them set image in picturebox to null and path to null
                currentPicturesList[0] = null;
                pictureBox1.Image = null;
            }
            //does same thing as first one but for second picture box
            if ((1 + offSet) < list.Count && File.Exists(((PictureClass)list[1 + offSet]).getPath()))
            {
                currentPicturesList[1] = ((PictureClass)list[1 + offSet]).getPath();
                Bitmap image2 = (Bitmap)Bitmap.FromFile(((PictureClass)list[1 + offSet]).getPath());
                Image newImag2 = image2.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox2.Image = newImag2;
            }
            else
            {
                currentPicturesList[1] = null;
                pictureBox2.Image = null;
            }
            if ((2 + offSet) < list.Count && File.Exists(((PictureClass)list[2 + offSet]).getPath()))
            {
                currentPicturesList[2] = ((PictureClass)list[2 + offSet]).getPath();
                Bitmap image3 = (Bitmap)Bitmap.FromFile(((PictureClass)list[2 + offSet]).getPath());
                Image newImag3 = image3.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox3.Image = newImag3;
            }
            else
            {
                currentPicturesList[2] = null;
                pictureBox3.Image = null;

            }
            if ((3 + offSet) < list.Count && File.Exists(((PictureClass)list[3 + offSet]).getPath()))
            {
                currentPicturesList[3] = ((PictureClass)list[3 + offSet]).getPath();
                Bitmap image4 = (Bitmap)Bitmap.FromFile(((PictureClass)list[3 + offSet]).getPath());
                Image newImag4 = image4.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox4.Image = newImag4;

            }
            else
            {
                currentPicturesList[4] = null;
                pictureBox4.Image = null;

            }
            if ((4 + offSet) < list.Count && File.Exists(((PictureClass)list[4 + offSet]).getPath()))
            {
                currentPicturesList[4] = ((PictureClass)list[4 + offSet]).getPath();
                Bitmap image5 = (Bitmap)Bitmap.FromFile(((PictureClass)list[4 + offSet]).getPath());
                Image newImag5 = image5.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox5.Image = newImag5;
            }
            else
            {
                currentPicturesList[4] = null;
                pictureBox5.Image = null;
            }

            //row #2

            if ((5 + offSet) < list.Count && File.Exists(((PictureClass)list[5 + offSet]).getPath()))
            {
                currentPicturesList[5] = ((PictureClass)list[5 + offSet]).getPath();
                Bitmap image6 = (Bitmap)Bitmap.FromFile(((PictureClass)list[5 + offSet]).getPath());
                Image newImag6 = image6.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox6.Image = newImag6;
            }
            else
            {
                currentPicturesList[5] = null;
                pictureBox6.Image = null;
            }
            if ((6 + offSet) < list.Count && File.Exists(((PictureClass)list[6 + offSet]).getPath()))
            {
                currentPicturesList[6] = ((PictureClass)list[6 + offSet]).getPath();
                Bitmap image7 = (Bitmap)Bitmap.FromFile(((PictureClass)list[6 + offSet]).getPath());
                Image newImag7 = image7.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox7.Image = newImag7;
            }
            else
            {
                currentPicturesList[6] = null;
                pictureBox7.Image = null;
            }
            if ((7 + offSet) < list.Count && File.Exists(((PictureClass)list[7 + offSet]).getPath()))
            {
                currentPicturesList[7] = ((PictureClass)list[7 + offSet]).getPath();
                Bitmap image8 = (Bitmap)Bitmap.FromFile(((PictureClass)list[7 + offSet]).getPath());
                Image newImag8 = image8.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox8.Image = newImag8;
            }
            else
            {
                currentPicturesList[7] = null;
                pictureBox8.Image = null;
            }
            if ((8 + offSet) < list.Count && File.Exists(((PictureClass)list[8 + offSet]).getPath()))
            {
                currentPicturesList[8] = ((PictureClass)list[8 + offSet]).getPath();
                Bitmap image9 = (Bitmap)Bitmap.FromFile(((PictureClass)list[8 + offSet]).getPath());
                Image newImag9 = image9.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox9.Image = newImag9;
            }
            else
            {
                currentPicturesList[8] = null;
                pictureBox9.Image = null;

            }
            if ((9 + offSet) < list.Count && File.Exists(((PictureClass)list[9 + offSet]).getPath()))
            {
                currentPicturesList[9] = ((PictureClass)list[9 + offSet]).getPath();
                Bitmap image10 = (Bitmap)Bitmap.FromFile(((PictureClass)list[9 + offSet]).getPath());
                Image newImag10 = image10.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox10.Image = newImag10;

            }
            else
            {
                currentPicturesList[9] = null;
                pictureBox10.Image = null;

            }

            //row 3


            if ((10 + offSet) < list.Count && File.Exists(((PictureClass)list[10 + offSet]).getPath()))
            {
                currentPicturesList[10] = ((PictureClass)list[10 + offSet]).getPath();
                Bitmap image11 = (Bitmap)Bitmap.FromFile(((PictureClass)list[10 + offSet]).getPath());
                Image newImag11 = image11.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox11.Image = newImag11;

            }
            else
            {
                currentPicturesList[10] = null;
                pictureBox11.Image = null;

            }
            if ((11 + offSet) < list.Count && File.Exists(((PictureClass)list[11 + offSet]).getPath()))
            {
                currentPicturesList[11] = ((PictureClass)list[11 + offSet]).getPath();
                Bitmap image12 = (Bitmap)Bitmap.FromFile(((PictureClass)list[11 + offSet]).getPath());
                Image newImag12 = image12.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox12.Image = newImag12;
            }
            else
            {
                currentPicturesList[11] = null;
                pictureBox12.Image = null;

            }
            if ((12 + offSet) < list.Count && File.Exists(((PictureClass)list[12 + offSet]).getPath()))
            {
                currentPicturesList[12] = ((PictureClass)list[12 + offSet]).getPath();
                Bitmap image13 = (Bitmap)Bitmap.FromFile(((PictureClass)list[12 + offSet]).getPath());
                Image newImag13 = image13.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox13.Image = newImag13;

            }
            else
            {
                currentPicturesList[12] = null;
                pictureBox13.Image = null;

            }
            if ((13 + offSet) < list.Count && File.Exists(((PictureClass)list[13 + offSet]).getPath()))
            {
                currentPicturesList[13] = ((PictureClass)list[13 + offSet]).getPath();
                Bitmap image14 = (Bitmap)Bitmap.FromFile(((PictureClass)list[13 + offSet]).getPath());
                Image newImag14 = image14.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox14.Image = newImag14;
            }
            else
            {
                currentPicturesList[13] = null;
                pictureBox14.Image = null;

            }
            if ((14 + offSet) < list.Count && File.Exists(((PictureClass)list[14 + offSet]).getPath()))
            {
                currentPicturesList[14] = ((PictureClass)list[14 + offSet]).getPath();
                Bitmap image15 = (Bitmap)Bitmap.FromFile(((PictureClass)list[14 + offSet]).getPath());
                Image newImag15 = image15.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox15.Image = newImag15;
            }
            else
            {
                currentPicturesList[14] = null;
                pictureBox15.Image = null;
            }

            //row 4


            if ((15 + offSet) < list.Count && File.Exists(((PictureClass)list[15 + offSet]).getPath()))
            {
                currentPicturesList[15] = ((PictureClass)list[15 + offSet]).getPath();
                Bitmap image16 = (Bitmap)Bitmap.FromFile(((PictureClass)list[15 + offSet]).getPath());
                Image newImag16 = image16.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox16.Image = newImag16;

            }
            else
            {
                currentPicturesList[15] = null;
                pictureBox16.Image = null;
 
            }
            if ((16 + offSet) < list.Count && File.Exists(((PictureClass)list[16 + offSet]).getPath()))
            {
                currentPicturesList[16] = ((PictureClass)list[16 + offSet]).getPath();
                Bitmap image17 = (Bitmap)Bitmap.FromFile(((PictureClass)list[16 + offSet]).getPath());
                Image newImag17 = image17.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox17.Image = newImag17;
                
            }
            else
            {
                currentPicturesList[16] = null;
                pictureBox17.Image = null;

            }
            if ((17 + offSet) < list.Count && File.Exists(((PictureClass)list[17 + offSet]).getPath()))
            {
                currentPicturesList[17] = ((PictureClass)list[17 + offSet]).getPath();
                Bitmap image18 = (Bitmap)Bitmap.FromFile(((PictureClass)list[17 + offSet]).getPath());
                Image newImag18 = image18.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox18.Image = newImag18;
                
            }
            else
            {
                currentPicturesList[17] = null;
                pictureBox18.Image = null;

            }
            if ((18 + offSet) < list.Count && File.Exists(((PictureClass)list[18 + offSet]).getPath()))
            {
                currentPicturesList[18] = ((PictureClass)list[18 + offSet]).getPath();
                Bitmap image19 = (Bitmap)Bitmap.FromFile(((PictureClass)list[18 + offSet]).getPath());
                Image newImag19 = image19.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox19.Image = newImag19;
                
            }
            else
            {
                currentPicturesList[18] = null;
                pictureBox19.Image = null;
                
            }

            if ((19 + offSet) < list.Count && File.Exists(((PictureClass)list[19 + offSet]).getPath()))
            {
                currentPicturesList[19] = ((PictureClass)list[19  + offSet]).getPath();
                Bitmap image20 = (Bitmap)Bitmap.FromFile(((PictureClass)list[19 + offSet]).getPath());
                Image newImag20 = image20.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                pictureBox20.Image = newImag20;
                
            }
            else
            {
                currentPicturesList[19] = null;
                pictureBox20.Image = null;

            }


        }
        //This function does the calculations on the pictures
        public void calculatePicture(string Picture, ArrayList PictureIntensity, ArrayList PictureColor)
        {
			//////////////////
            //add your code//
			//////////////////
        }
        //reset screen if new search is clicked
        private void NewSearch_Click(object sender, EventArgs e)
        {
            originalForm.Show();
            this.Hide();
        }
        //reset window is next button is clicked
        private void Next_Click(object sender, EventArgs e)
        {
            panel1.VerticalScroll.Value = 0;
            panel1.VerticalScroll.Value = 0;
            panel1.HorizontalScroll.Value = 0; //assign the position value    
            panel1.HorizontalScroll.Value = 0;


            if (page < (totalPages - 1))
            {
                page += 1;
                pageLabel.Text = "Page "+ (page+1) + "/Out of " + totalPages;
                displayResults();
            }
            else
            {
                page = 0;
                pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
                displayResults();

            }
        }
        //reset window if previous button is clicked
        private void Previous_Click(object sender, EventArgs e)
        {
            panel1.VerticalScroll.Value = 0;
            panel1.VerticalScroll.Value = 0;
            panel1.HorizontalScroll.Value = 0; //assign the position value    
            panel1.HorizontalScroll.Value = 0;


            if (page >  0)
            {
                page -= 1;
                pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
                displayResults();
            }
            else
            {
                page = (totalPages - 1);
                pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
                displayResults();

            }
        }
        //clear info if application closed
        private void ResultofSearch_FormClosing(object sender, FormClosingEventArgs e)
        {
            originalForm.Close();

        }
        //reset window if method is changed
        private void checkBox1_checkBox_Click(object sender, EventArgs e)
        {

            checkBox1.Checked = true;
            checkBox2.Checked = false;
            useMethod1 = true;
            page = 0;
            sortArray(list);        
            pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
            displayResults();

        }
        //reset window if method is changed
        private void checkBox2_checkBox_Click(object sender, EventArgs e)
        {
            
            checkBox2.Checked = true;
            checkBox1.Checked = false;
            useMethod1 = false;
            page = 0;
            sortArray(list); 
            pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
            displayResults();
        }
        //method needed to create thumbnails
        public bool ThumbnailCallback()
        {
            return true;
        }
//The following section are the methods needed to allow application to open full images when thumbnails are clicked
//Each checks to see if path has been set then it passes path to the form used to open image
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[0] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[0]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[0], name);
                displayForm.Show();
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[1] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[1]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[1], name);
                displayForm.Show();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[2] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[2]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[2], name);
                displayForm.Show();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[3] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[3]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[3], name);
                displayForm.Show();
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[4] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[4]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[4], name);
                displayForm.Show();
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[5] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[5]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[5], name);
                displayForm.Show();
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[6] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[6]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[6], name);
                displayForm.Show();
            }
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[7] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[7]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[7], name);
                displayForm.Show();
            }
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[8] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[8]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[8], name);
                displayForm.Show();
            }
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[9] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[9]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[9], name);
                displayForm.Show();
            }
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[10] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[10]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[10], name);
                displayForm.Show();
            }
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[11] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[11]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[11], name);
                displayForm.Show();
            }
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[12] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[12]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[12], name);
                displayForm.Show();
            }
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[13] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[13]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[13], name);
                displayForm.Show();
            }
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[14] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[14]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[14], name);
                displayForm.Show();
            }
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[15] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[15]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[15], name);
                displayForm.Show();
            }
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[16] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[16]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[16], name);
                displayForm.Show();
            }
        }

        private void pictureBox18_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[17] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[17]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[17], name);
                displayForm.Show();
            }
        }

        private void pictureBox19_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[18] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[18]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[18], name);
                displayForm.Show();
            }
        }

        private void pictureBox20_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[20] != null)
            {
                displayForm = new DisplayPicture(this);
                string[] parts = ((string)currentPicturesList[19]).Split('\\');
                string name = parts[(parts.Length - 1)];
                displayForm.displayPicture((string)currentPicturesList[19], name);
                displayForm.Show();
            }
        }    
    }
}
