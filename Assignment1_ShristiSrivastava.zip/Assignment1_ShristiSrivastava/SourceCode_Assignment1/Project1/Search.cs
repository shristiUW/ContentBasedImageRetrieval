﻿using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace Project1
{
    public partial class Search : Form
    {
        string queryFileName;
        Results resultForm;
        public Search()
        {
            InitializeComponent();
            btnSearch.Enabled = false;
            btnReset.Enabled = false;
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
           //Open windows dialog and limit it to jpeg file only
            openFileDialog.Filter = "JPEG Files|*.jpg";
            openFileDialog.FilterIndex = 1;
            openFileDialog.FileName = "";
            openFileDialog.ShowDialog();

            if (openFileDialog.FileName != "")
            {
                //Open the file from the dialog and show it in the picute box
                queryFileName = openFileDialog.FileName;
                Bitmap myImg = (Bitmap)Bitmap.FromFile(queryFileName);

                // Set the size of the queryPicture PictureBox to match the image dimensions
                int hor = myImg.Height;
                int width = myImg.Width;
                Size newS = new Size(width, hor);
                queryPicture.Size = newS;

                // Display the selected image in the queryPicture PictureBox
                queryPicture.Image = myImg;

                // Enable the Search and Reset buttons
                btnSearch.Enabled = true;
                btnReset.Enabled = true;
            }
        }


        //set up the right check box when it is clicked
        private void checkBoxIntensity_Click(object sender, EventArgs e)
        {
            checkBoxIntensity.Checked = true;
            checkBoxColor.Checked = false;

        }
        private void checkBoxColor_Click(object sender, EventArgs e)
        {
            checkBoxColor.Checked = true;
            checkBoxIntensity.Checked = false;
        }

        //When search button clicked pass information to the form to display it to screen
        private void btnSearch_Click(object sender, EventArgs e)
        {
            FileInfo newFile = new FileInfo(queryFileName);
            string path = newFile.DirectoryName;
            resultForm = new Results(this,checkBoxIntensity.Checked);
            resultForm.doSearch(queryFileName, path, checkBoxIntensity.Checked, checkBoxColor.Checked);
            resultForm.Show();
            this.Hide();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            queryPicture.Image = null;
            btnSearch.Enabled = false;
        }

    }




}


