﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Image = System.Drawing.Image;
using System.Threading.Tasks;


namespace Project1
{
    public partial class Results : Form
    {
        //set up global varabiles for class
        private Dictionary<string, Image> imageCache = new Dictionary<string, Image>();
        Search originalForm;
        List<string> currentPicturesList = new List<string>(20);
        List<PictureClass> list = new List<PictureClass>();
        string queryMainPicture;
        string folderMainPath;
        int page;
        int totalPages;
       

           public Results(Search form, bool checkbox)
           {
            //initialize information when form is created
            originalForm = form;
            InitializeComponent();
            currentPicturesList = new List<string>(20);
           
            // Initialize currentPicturesList with 20 null elements
            currentPicturesList = Enumerable.Repeat<string>(null, 20).ToList();           

           }

        //        
        //function to search through database based on the Query Picture sent in
        public void doSearch(string QueryPicture, string folderPath, bool chkBoxIntensity, bool chkBoxColor)
        {
            //setting query picture in class variable so that we can access it in checkbox click
            queryMainPicture = QueryPicture;
            folderMainPath = folderPath;
            //Process Query image 
            Bitmap myImg = (Bitmap)Bitmap.FromFile(QueryPicture);
            int qWidth = myImg.Width;
            int qHeight = myImg.Height;
            list.Clear();

            // Initialize histograms based on the method - color code or intensity
            int[] histogramMyImg = new int[chkBoxColor ? 65 : 26];
            Action<Bitmap, int[], int, int> calculateHistogram;
            if (chkBoxColor)
            {
                calculateHistogram = (img, hist, width, height) =>
                {
                    calculateColorCode(img, width, height, hist);
                };

            }
            else
            {

                calculateHistogram = (img, hist, width, height) =>
                {
                    calculateIntensity(img, width, height, hist);
                };

            }
            //Histogram of selected query picture
            calculateHistogram(myImg, histogramMyImg, qWidth, qHeight);

            string[] similarImagesJPG = Directory.GetFiles(folderPath)
                .Where(file => file.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase))
                .ToArray();

            // Early return if there are no similar images
            if (similarImagesJPG.Length == 0)
            {
                return;
            }
            //Parallel processing image for fast results
            Parallel.ForEach(similarImagesJPG, (similarImageFile) =>
            {

                if (!string.Equals(similarImageFile, QueryPicture, StringComparison.OrdinalIgnoreCase))
                {
                    double distance = 0.0;
                    using (Stream imageStream = File.OpenRead(similarImageFile))
                    {
                        Bitmap similarImageBitMap = (Bitmap)Bitmap.FromStream(imageStream);
                        int sWidth = similarImageBitMap.Width;
                        int sHeight = similarImageBitMap.Height;
                        int[] histogramSimilarImg = new int[chkBoxColor ? 65 : 26];
                        calculateHistogram(similarImageBitMap, histogramSimilarImg, sWidth, sHeight);
                        distance = calculateDistance(histogramMyImg, histogramSimilarImg, chkBoxColor ? 65 : 26);
                    }

                    if (chkBoxColor)
                    {
                        list.Add(new PictureClass(similarImageFile, 0, distance));
                    }
                    else
                    {
                        list.Add(new PictureClass(similarImageFile, distance, 0));
                    }

            }

            });

            // Sort the list
            // To compare by color code:
            if (chkBoxColor)
            {
                var comparerByColor = new PictureClassComparer(true);
                list.Sort(comparerByColor);
            }
            else
            {

                //To compare by intensity:
                var comparerByIntensity = new PictureClassComparer(false);
                list.Sort(comparerByIntensity);
            }


              //calculate the number of pages needed if we want 20 pictures per page
              double numberPerPage = (list.Count / 20.0);
              totalPages = (int)Math.Ceiling(numberPerPage);
              pageLabel.Text = "Page 1 /Out of " + totalPages;
              page = 0;
              //resize the picture box for the query image
              Size newS = new Size(qWidth, qHeight);
              qPicture.Size = newS;
              Image imageQ = myImg;
              qPicture.Image = imageQ;
              //set up the check next to the right check box
              if (chkBoxIntensity)
              {
                  checkBox1.Checked = true;
                  checkBox2.Checked = false;
              }
              else
              {
                  checkBox2.Checked = true;
                  checkBox1.Checked = false;
              }
              //display picture to screen
              displayResults();

          }

        //Distance calculation based on Histogram result  
        double calculateDistance(int[] histogram1, int[] histogram2, int size)
        {
            double distance = 0.0;

            for (int i = 1; i < size; i++)
            {
                double term1 = histogram1[i] * 1.0 / histogram1[0] * 1.0;
                double term2 = histogram2[i] * 1.0 / histogram2[0] * 1.0;
                distance += Math.Abs(term1 - term2);
            }
            return distance;

        }
        // Intensity calculation method
        void calculateIntensity(Bitmap img, int width, int height, int[] histogram)
        {
            int binSize = 10;
            int binNumber;
            //Storing size of image for faster distance calculation
            histogram[0] = width * height;
            //iterate each pixel of the image 
            for (int i = 0; i < img.Width; i++)
            {
                for (int j = 0; j < img.Height; j++)
                {
                    Color pixel = img.GetPixel(i, j);
                    double intensity = .299 * (pixel.R) + .587 * (pixel.G) + .114 * (pixel.B);
                    //last bin size will be 15 
                    if (intensity >= 250)
                    {
                        binNumber = (int)(intensity / binSize);
                    }
                    else
                    {
                        binNumber = (int)(intensity / binSize) + 1;
                    }
                    // Increment the corresponding bin in the histogram
                    histogram[binNumber]++;                   
                }
            }
        }
        //calculate color code
        void calculateColorCode(Bitmap img, int width, int height, int[] histogram)
        {
            Color pixel;
            int red, blue, green, colorCode;
            histogram[0] = width * height;
            //iterate each pixel of the image 
            for (int i = 0; i < img.Width; i++)
            {
                for (int j = 0; j < img.Height; j++)
                {
                    pixel = img.GetPixel(i, j);
                    red = pixel.R >> 6;
                    green = pixel.G >> 6;
                    blue = pixel.B >> 6;
                    // Extract the most significant 2 bits from each color component
                    //apply | bitwise or operator
                    colorCode = (red << 4) | (green << 2) | (blue);

                    // Increment the corresponding bin in the histogram
                    histogram[colorCode + 1]++;

                }
            }
        }

        //this function displays the results of the search to the screen
        public void displayResults()
        {
            int itemsPerPage = 20;

            for (int i = 0; i < itemsPerPage; i++)
            {
                int currentIndex = page * itemsPerPage + i;

                PictureBox pictureBox = this.Controls.Find($"pictureBox{i + 1}", true).FirstOrDefault() as PictureBox;

                if (currentIndex < list.Count && File.Exists(list[currentIndex].getPath()))
                {
                    string imagePath = list[currentIndex].getPath();

                    currentPicturesList[i] = imagePath;

                    if (imageCache.TryGetValue(imagePath, out Image cachedImage))
                    {
                        // Use the cached image
                        pictureBox.Image = cachedImage;
                    }
                    else
                    {
                        // Load and cache the image
                        using (Bitmap bitmap = (Bitmap)Bitmap.FromFile(imagePath))
                        {
                            Image image = bitmap.GetThumbnailImage(150, 150, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);

                            if (pictureBox != null)
                            {
                                pictureBox.Image = image;
                            }

                            // Cache the loaded image
                            imageCache[imagePath] = image;
                        }
                    }
                }
                else
                {
                    currentPicturesList[i] = null;

                    if (pictureBox != null)
                    {
                        pictureBox.Image = null;
                    }
                }
            }
        }

        //reset screen if new search is clicked
        private void NewSearch_Click(object sender, EventArgs e)
        {
            originalForm.Show();
            this.Hide();
        }
        //reset window is next button is clicked
        private void Next_Click(object sender, EventArgs e)
        {
            panel1.VerticalScroll.Value = 0;
            panel1.VerticalScroll.Value = 0;
            panel1.HorizontalScroll.Value = 0; //assign the position value    
            panel1.HorizontalScroll.Value = 0;


            if (page < (totalPages - 1))
            {
                page += 1;
                pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
                displayResults();
            }
            else
            {
                page = 0;
                pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
                displayResults();

            }
        }
        //reset window if previous button is clicked
        private void Previous_Click(object sender, EventArgs e)
        {
            panel1.VerticalScroll.Value = 0;
            panel1.VerticalScroll.Value = 0;
            panel1.HorizontalScroll.Value = 0; //assign the position value    
            panel1.HorizontalScroll.Value = 0;


            if (page > 0)
            {
                page -= 1;
                pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
                displayResults();
            }
            else
            {
                page = (totalPages - 1);
                pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
                displayResults();

            }
        }
        //clear info if application closed
        private void ResultofSearch_FormClosing(object sender, FormClosingEventArgs e)
        {
            originalForm.Close();

        }
        //load images as per the result of checkbox
        private void checkBox1_checkBox_Click(object sender, EventArgs e)
        {

            checkBox1.Checked = true;
            checkBox2.Checked = false;
            page = 0;
               
            pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
            string queryFilePath = qPicture.ImageLocation;
            if (string.IsNullOrEmpty(queryFilePath))
            {
                queryFilePath = queryMainPicture;
            }
            doSearch(queryFilePath, folderMainPath, checkBox1.Checked, checkBox2.Checked);

        }
        //load images as per the result of checkbox
        private void checkBox2_checkBox_Click(object sender, EventArgs e)
        {

            checkBox2.Checked = true;
            checkBox1.Checked = false;
            page = 0;
           
            pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
            string queryFilePath = qPicture.ImageLocation;
            if (string.IsNullOrEmpty(queryFilePath))
            {
                queryFilePath = queryMainPicture;
            }
            doSearch(queryFilePath, folderMainPath, checkBox1.Checked, checkBox2.Checked);
        }
        //method needed to create thumbnails
        public bool ThumbnailCallback()
        {
            return true;
        }
       //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[0] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[0].ToString());
                qPicture.ImageLocation = currentPicturesList[0].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                pageLabel.Text = "Page " + (page + 1) + "/Out of " + totalPages;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);

            }

        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[1] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[1].ToString());
                qPicture.ImageLocation = currentPicturesList[1].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[2] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[2].ToString());
                qPicture.ImageLocation = currentPicturesList[2].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[3] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[3].ToString());
                qPicture.ImageLocation = currentPicturesList[3].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[4] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[4].ToString());
                qPicture.ImageLocation = currentPicturesList[4].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox6_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[5] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[5].ToString());
                qPicture.ImageLocation = currentPicturesList[5].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);

            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[6] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[6].ToString());
                qPicture.ImageLocation = currentPicturesList[6].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[7] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[7].ToString());
                qPicture.ImageLocation = currentPicturesList[7].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox9_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[8] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[8].ToString());
                qPicture.ImageLocation = currentPicturesList[8].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox10_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[9] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[9].ToString());
                qPicture.ImageLocation = currentPicturesList[9].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox11_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[10] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[10].ToString());
                qPicture.ImageLocation = currentPicturesList[10].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox12_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[11] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[11].ToString());
                qPicture.ImageLocation = currentPicturesList[11].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox13_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[12] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[12].ToString());
                qPicture.ImageLocation = currentPicturesList[12].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox14_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[13] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[13].ToString());
                qPicture.ImageLocation = currentPicturesList[13].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox15_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[14] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[14].ToString());
                qPicture.ImageLocation = currentPicturesList[14].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox16_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[15] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[15].ToString());
                qPicture.ImageLocation = currentPicturesList[15].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox17_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[16] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[16].ToString());
                qPicture.ImageLocation = currentPicturesList[16].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox18_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[17] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[17].ToString());
                qPicture.ImageLocation = currentPicturesList[17].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox19_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[18] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[18].ToString());
                qPicture.ImageLocation = currentPicturesList[18].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }
        //Clicking picture will load file in the main window and update the search result based on this image and selected method
        private void pictureBox20_Click(object sender, EventArgs e)
        {
            if (currentPicturesList[19] != null)
            {
                Bitmap myImage = new Bitmap(currentPicturesList[19].ToString());
                qPicture.ImageLocation = currentPicturesList[19].ToString();
                qPicture.Size = myImage.Size;
                qPicture.Image = myImage;
                doSearch(qPicture.ImageLocation, folderMainPath, checkBox1.Checked, checkBox2.Checked);
            }
        }

    }
}
