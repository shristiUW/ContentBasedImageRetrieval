﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project1
{
    internal class PictureClassComparer : IComparer<PictureClass>
    {
        private bool compareByColorCode;  // A flag to specify whether to compare by color code

        public PictureClassComparer(bool compareByColorCode)
        {
            this.compareByColorCode = compareByColorCode;
        }

        public int Compare(PictureClass p1, PictureClass p2)
        {
            PictureClass picture1 = (PictureClass)p1;
            PictureClass picture2 = (PictureClass)p2;

            if (picture1 == null && picture2 == null)
            {
                return 0; // Both are null, consider them equal.
            }
            else if (picture1 == null)
            {
                return -1; // p1 is null, p2 is not null, treat p1 as less than p2.
            }
            else if (picture2 == null)
            {
                return 1; // p2 is null, p1 is not null, treat p1 as greater than p2.
            }

            if (compareByColorCode)
            {
                // Compare based on Method2 (color code)
                return picture1.getMethod2().CompareTo(picture2.getMethod2());
            }
            else
            {
                // Compare based on Method1 (intensity)
                return picture1.getMethod1().CompareTo(picture2.getMethod1());
            }
        }
    }

}
